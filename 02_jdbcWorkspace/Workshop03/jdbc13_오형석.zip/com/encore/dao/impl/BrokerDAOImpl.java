package com.encore.dao.impl;

import com.encore.dao.BrokerDAO;
import com.encore.vo.Stock;
import com.encore.vo.User;

public class BrokerDAOImpl implements BrokerDAO {

	@Override
	public void registerMember(User user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteMember(User user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateMember(User user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Stock findByPrice(int price) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void printAllStock() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printAllUser() {
		// TODO Auto-generated method stub
		
	}

}
